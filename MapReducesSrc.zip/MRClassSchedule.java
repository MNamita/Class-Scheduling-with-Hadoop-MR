import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MRClassSchedule {
	public static class TokenizerMapper
	extends Mapper<Object, Text, Text, IntWritable>{
	private static IntWritable one = new IntWritable(1);
	private static IntWritable flag = new IntWritable(0);
	private static IntWritable flagcheck = new IntWritable(0);
	private Text word = new Text();
	public void map(Object key, Text value, Context context
	) throws IOException, InterruptedException {
		String oneentry=value.toString();
		String[] data=oneentry.split(",");
		if (data[2].equalsIgnoreCase("Unknown"))	
		{ flag.set(1);}
		String room_building=data[2];
		String[] rooms=room_building.split("\\s+");
		if (rooms[0].equalsIgnoreCase("Arr")) 
		{ flag.set(1);} 
		String building=rooms[0];
		String sem=data[1];
		String key_word=building;
		key_word=key_word.concat("_");
		key_word=key_word.concat(sem);
		word.set(key_word);
		try {
			int count= Integer.parseInt(data[7]);
			one.set(count); 
			if (flag.equals(flagcheck))
			{
				context.write(word, one);
			}
		} catch (NumberFormatException e)
			{}

		flag.set(0);
	}
}
public static class IntSumReducer
extends Reducer<Text,IntWritable,Text,IntWritable> {
private IntWritable result = new IntWritable();
public void reduce(Text key, Iterable<IntWritable> values,
Context context
) throws IOException, InterruptedException {
int sum = 0;
for (IntWritable val : values) {
sum += val.get();
}
result.set(sum);
context.write(key, result);
}
}

public static void main(String[] args) throws Exception {
	Configuration conf = new Configuration();
	Job job = Job.getInstance(conf, "MR ClassSchedule");
	job.setJarByClass(MRClassSchedule.class);
	job.setMapperClass(TokenizerMapper.class);
	job.setCombinerClass(IntSumReducer.class);
	job.setReducerClass(IntSumReducer.class);
	job.setOutputKeyClass(Text.class);
	job.setOutputValueClass(IntWritable.class);
	FileInputFormat.addInputPath(job, new Path(args[0]));
	FileOutputFormat.setOutputPath(job, new Path(args[1]));
	System.exit(job.waitForCompletion(true) ? 0 : 1);
}
}
